#include <iostream>
#include <bitset>

using namespace std;

int main(int argc, char const *argv[])
{
    cout << bitset<32> (32) << endl;
    return 0;
}