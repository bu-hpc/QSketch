#pragma once



template <typename T>
struct Test {
    T val;
};

template <typename T>
Test<T> test;